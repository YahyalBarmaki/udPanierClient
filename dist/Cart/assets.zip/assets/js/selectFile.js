function hello() {
    alert("Hello");
}